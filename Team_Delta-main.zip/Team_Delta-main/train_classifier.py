import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_extraction.text import CountVectorizer
import joblib

# Load the data
data = pd.read_csv('mental_health_keywords.csv')

# Strip whitespace from column names to avoid KeyError
data.columns = data.columns.str.strip()

# Print column names to debug
print("Column Names:", data.columns.tolist())

# Check for missing values
if data.isnull().any().any():
    print("Warning: Missing values found in the dataset. Please clean the data.")

# Extract features and labels
X = data['Keywords']
y = data['Mental Health State']  # Ensure the case matches the CSV header

# Initialize vectorizer and fit it on keywords
vectorizer = CountVectorizer()
X_vectorized = vectorizer.fit_transform(X)

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X_vectorized, y, test_size=0.2, random_state=42)

# Create and train the Random Forest classifier
classifier = RandomForestClassifier(n_estimators=100, random_state=42)
classifier.fit(X_train, y_train)

# Evaluate the model (optional)
accuracy = classifier.score(X_test, y_test)
print(f"Model accuracy on test set: {accuracy:.2f}")

# Save the trained model and the vectorizer
joblib.dump(classifier, 'concern_classifier_model.pkl')
joblib.dump(vectorizer, 'vectorizer.pkl')

print("Model training complete and saved as 'concern_classifier_model.pkl' and 'vectorizer.pkl'.")
