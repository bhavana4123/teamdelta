import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report
from sklearn.preprocessing import LabelEncoder
from sklearn.utils import class_weight
import joblib

# Load the dataset
data = pd.read_csv('delta_final.csv')

# Define feature columns and target variable
features = ['age', 'gender', 'physical_health', 'mental_health', 'employment', 'sleep', 'stress', 'smoking', 'drinking']
target = 'mental_health'

# Prepare features and target
X = data[features]

# Check unique values in the target variable before mapping
print("Unique values in target variable before mapping:")
print(data[target].unique())

# Now we will inspect the unique values and decide the mapping
unique_target_values = data[target].unique()

# Replace this with your actual mapping based on your findings
# This example assumes you have categories in your dataset
y_mapping = {
    0: 0,   # Normal
    1: 1,   # Anxiety
    2: 2,   # Stress
    3: 3,   # Depression
    4: 4,   # Suicidal thoughts
    # Add any additional mappings necessary
}

# Map the target variable
data[target] = data[target].map(y_mapping)

# Check for NaN values in the target variable after mapping
print("Checking for missing values after mapping:")
missing_values = data[target].isnull().sum()
print(missing_values)

# Drop rows with NaN values in the target variable
data = data.dropna(subset=[target])

# Prepare encoded target variable
y_encoded = data[target]

# Check if any rows remain after dropping NaNs
print(f"Remaining rows after dropping NaNs: {len(data)}")

# Prepare features after dropping NaNs
X = data[features].loc[data[target].notnull()]

# Proceed if we have valid data
if len(data) == 0:
    print("No valid data available for training. Exiting...")
else:
    # Split the data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y_encoded, test_size=0.2, random_state=42, stratify=y_encoded)

    # Calculate class weights to handle imbalanced classes
    class_weights = class_weight.compute_class_weight('balanced', classes=np.unique(y_encoded), y=y_encoded)
    class_weights_dict = {i: class_weights[i] for i in range(len(class_weights))}

    # Train a RandomForestClassifier with GridSearchCV
    param_grid = {
        'n_estimators': [100, 200],
        'max_depth': [None, 10, 20],
        'min_samples_split': [2, 5],
        'min_samples_leaf': [1, 2],
    }

    rf = RandomForestClassifier(class_weight=class_weights_dict, random_state=42)
    grid_search = GridSearchCV(rf, param_grid, cv=3, verbose=2, n_jobs=-1)

    # Fit the model
    grid_search.fit(X_train, y_train)

    # Evaluate the model
    y_pred = grid_search.predict(X_test)

    print("Classification Report:")
    print(classification_report(y_test, y_pred))

    # Save the model and the label encoder
    joblib.dump(grid_search.best_estimator_, 'mental_health_model.pkl')

    # Create and save the label encoder for future use in app.py
    le = LabelEncoder()
    le.fit(["Normal", "Anxiety", "Stress", "Depression", "Suicidal thoughts"])  # Adjust as necessary
    joblib.dump(le, 'label_encoder.pkl')  # Save the label encoder with the correct mapping
