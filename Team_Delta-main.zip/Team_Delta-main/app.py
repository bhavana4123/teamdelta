from flask import Flask, request, render_template
import joblib
import numpy as np
from textblob import TextBlob  # For sentiment analysis
import spacy  # For keyword extraction
import pandas as pd  # To load and manage CSV data

app = Flask(__name__)

# Load the models
model = joblib.load('mental_health_model.pkl')  # Model for demographic prediction
classifier_model = joblib.load('concern_classifier_model.pkl')  # Model for keyword classification
vectorizer = joblib.load('vectorizer.pkl')  # Load the fitted CountVectorizer

# Load the spaCy model
nlp = spacy.load("en_core_web_sm")

# Load the mental health keywords from CSV
keywords_data = pd.read_csv('mental_health_keywords.csv')
keywords_data.columns = keywords_data.columns.str.strip()  # Strip whitespace from column names
# Create a mapping from keywords to mental health states
keywords_mapping = {row['Keywords']: row['Mental Health State'] for index, row in keywords_data.iterrows()}

# Define the mapping from numerical predictions to mental health states
mental_health_mapping = {
    0: "Normal",
    1: "Anxiety",
    2: "Stress",
    3: "Depression",
    4: "Suicidal thoughts"
}

# Define severity scores for mental health states
severity_scores = {
    "Normal": 0,
    "Anxiety": 1,
    "Stress": 2,
    "Depression": 4,
    "Suicidal thoughts": 5
}

# Tailored messages and precautions
messages_precautions = {
    "Normal": {
        "message": "You're doing well! Keep up the good work in maintaining your mental health.",
        "precautions": [
            "Continue engaging in activities that bring you joy.",
            "Maintain a balanced lifestyle with regular exercise and healthy eating.",
            "Stay connected with friends and family."
        ]
    },
    "Stress": {
        "message": "It seems you're experiencing some stress. Here are some tips to manage it:",
        "precautions": [
            "Practice relaxation techniques such as deep breathing or meditation.",
            "Make time for hobbies or activities you enjoy.",
            "Consider talking to someone about what's stressing you."
        ]
    },
    "Anxiety": {
        "message": "Anxiety can be tough to handle. Remember, you are not alone.",
        "precautions": [
            "Practice mindfulness and grounding techniques.",
            "Limit caffeine and alcohol intake.",
            "Seek support from friends, family, or a mental health professional."
        ]
    },
    "Depression": {
        "message": "It looks like you may be dealing with feelings of depression.",
        "precautions": [
            "Reach out to a trusted friend or family member.",
            "Engage in physical activity to boost your mood.",
            "Consider speaking with a mental health professional for guidance."
        ]
    },
    "Suicidal thoughts": {
        "message": "It's crucial to talk about these feelings. Your safety is the top priority.",
        "precautions": [
            "Reach out to a trusted person immediately.",
            "Consider contacting a mental health professional or a crisis hotline.",
            "Avoid isolation; stay connected with people who care about you."
        ]
    }
}

# List to store history of predictions
history = []

def analyze_sentiment(text):
    """Analyze sentiment and return polarity score and overall sentiment."""
    analysis = TextBlob(text)
    polarity = analysis.sentiment.polarity
    if polarity > 0:
        return polarity, "Positive"
    elif polarity < 0:
        return polarity, "Negative"
    else:
        return polarity, "Neutral"

def extract_keywords(text):
    """Extract keywords from text using spaCy and POS tagging."""
    doc = nlp(text)
    keywords = []
    for token in doc:
        # Extract adjectives, nouns, and verbs
        if token.pos_ in {"ADJ", "NOUN", "VERB"}:  # Include more parts of speech
            keywords.append(token.text)
    return keywords if keywords else ["No specific keywords detected"]

def classify_keywords(keywords):
    """Classify the extracted keywords into mental health states using the keywords_mapping."""
    classified_states = set()  # To collect all matching states

    for keyword in keywords:
        # Check if the keyword exists in the mapping
        state = keywords_mapping.get(keyword)
        
        # Debugging: Print the current keyword and its corresponding state
        print(f"Keyword: {keyword}, Classified State: {state}")  # Print the keyword being checked

        if state:
            classified_states.add(state)

    # Debugging: Print the collected classified states
    print(f"Classified States Collected: {classified_states}")  # Print all matched states

    # Return the classified state or "Unknown" if no matches found
    return ", ".join(classified_states) if classified_states else "Unknown"

def score_intensity(classified_state):
    """Score the intensity of the mental health concern based on the classified state."""
    if classified_state == "Unknown":
        return 0
    else:
        states = classified_state.split(", ")
        # Calculate average severity score for the classified states
        scores = [severity_scores[state] for state in states if state in severity_scores]
        return sum(scores) / len(scores) if scores else 0

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get input data from form
        age = int(request.form['age'])
        gender = int(request.form['gender'])
        physical_health = int(request.form['physical_health'])
        mental_health = int(request.form['mental_health'])
        employment = int(request.form['employment'])
        sleep = float(request.form['sleep'])
        stress = int(request.form['stress'])
        smoking = int(request.form['smoking'])
        drinking = int(request.form['drinking'])
        
        # Get user input text for sentiment analysis
        user_input_text = request.form['user_input']

        # Analyze sentiment of the user input text
        sentiment_score, sentiment_analysis = analyze_sentiment(user_input_text)

        # Extract keywords based on the text
        keywords = extract_keywords(user_input_text)

        # Classify the extracted keywords
        classified_state = classify_keywords(keywords)

        # Score the intensity of the concern
        intensity_score = score_intensity(classified_state)

        # Prepare input data for demographic prediction
        input_data = np.array([[age, gender, physical_health, mental_health, employment, sleep, stress, smoking, drinking]])
        
        # Predict the mental health state based on demographic data
        prediction = model.predict(input_data)
        
        # Map the prediction to the mental health state name
        predicted_state = mental_health_mapping.get(prediction[0], "Unknown")

        # Store the prediction history
        history.append({
            'age': age,
            'gender': gender,
            'physical_health': physical_health,
            'mental_health': mental_health,
            'employment': employment,
            'sleep': sleep,
            'stress': stress,
            'smoking': smoking,
            'drinking': drinking,
            'user_input': user_input_text,
            'predicted_state': predicted_state,
            'sentiment_score': sentiment_score,
            'sentiment_analysis': sentiment_analysis,
            'keywords': ", ".join(keywords),
            'classified_state': classified_state,
            'intensity_score': intensity_score
        })

        # Fetch messages and precautions based on predicted state
        precautions = messages_precautions.get(predicted_state, {
            "message": "No specific message available.",
            "precautions": []
        })

        return render_template(
            'result.html',
            result=predicted_state,
            sentiment_score=sentiment_score,
            sentiment_analysis=sentiment_analysis,
            keywords=", ".join(keywords),
            classified_state=classified_state,  # Send classified state to the template
            intensity_score=intensity_score,  # Send intensity score to the template
            messages_precautions=precautions  # Send messages and precautions to the template
        )
    except Exception as e:
        return str(e)

@app.route('/history')
def show_history():
    """Display the history of predictions."""
    return render_template('history.html', history=history)

if __name__ == "__main__":
    app.run(debug=True)
